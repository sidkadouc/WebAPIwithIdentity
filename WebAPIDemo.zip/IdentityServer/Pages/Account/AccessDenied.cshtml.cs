using Microsoft.AspNetCore.Mvc.RazorPages;

namespace IdentityServer.Pages.Account;

public class AccessDeniedModel : PageModel
{
    public void OnGet()
    {
    }
}