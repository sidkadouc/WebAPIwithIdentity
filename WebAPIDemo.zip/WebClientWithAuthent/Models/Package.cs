﻿namespace WebClientWithAuthent.Models
{
    public class Package
    {
        public string Name { get; set; }
        public int Id { get; set; }
    }
}
