﻿namespace WebAPIDemo.Services
{
    public interface IRolesService
    {
    }
}